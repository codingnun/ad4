package com.example.experiment_4_pre_final;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {
    public DBHandler(@Nullable Context context) {
        super(context, "student_data",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE student_data(subject VARCHAR(30),gender VARCHAR(30),qualif VARCHAR(30))");
    }
    public void addRows(String s,String g,String q){
        SQLiteDatabase db=getWritableDatabase();
        db.execSQL("DELETE FROM student_data");
        ContentValues cv=new ContentValues();
        cv.put("subject",s);
        cv.put("gender",g);
        cv.put("qualif",q);
        db.insert("student_data",null,cv);
    }
    public ArrayList<Show>getRow(){
        SQLiteDatabase db=getReadableDatabase();
        Cursor cur=db.rawQuery("SELECT * FROM student_data",null);
        cur.moveToFirst();
        ArrayList<Show>l=new ArrayList<>();
        Show obj=new Show();
        obj.s=cur.getString(0);
        obj.g=cur.getString(1);
        obj.q=cur.getString(2);
        l.add(obj);
        return l;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
