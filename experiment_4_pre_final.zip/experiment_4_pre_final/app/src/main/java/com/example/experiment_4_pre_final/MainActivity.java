package com.example.experiment_4_pre_final;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    String[] content={"FOC","AD","DM"};
    String gen,qual;
    String selected;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        RadioButton m=findViewById(R.id.radioButton);
        RadioButton f=findViewById(R.id.radioButton1);

        CheckBox u=findViewById(R.id.checkBox);
        CheckBox p=findViewById(R.id.checkBox1);

        Spinner spn=findViewById(R.id.spinner);
        spn.setOnItemSelectedListener(this);
        ArrayAdapter<String>adp=new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,content);
        adp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spn.setAdapter(adp);
        Button btn=findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(m.isChecked()){
                    gen="Male";
                }
                if(f.isChecked()){
                    gen="Female";
                }
                if(u.isChecked()){
                    qual="UG";
                }
                if(p.isChecked()){
                    qual="PG";
                }
                DBHandler dbHandler=new DBHandler(MainActivity.this);
                dbHandler.addRows(selected,gen,qual);
                Intent I=new Intent(MainActivity.this,Show.class);
                startActivity(I);
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        selected=content[position];
        Toast.makeText(this, selected, Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}