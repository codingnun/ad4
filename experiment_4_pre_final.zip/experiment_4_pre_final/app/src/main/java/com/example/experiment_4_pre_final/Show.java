package com.example.experiment_4_pre_final;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class Show  extends AppCompatActivity {
    String s,g,q;

    DBHandler db=new DBHandler(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.show_main);
        TextView tv=findViewById(R.id.textView);
        TextView tv1=findViewById(R.id.textView1);
        TextView tv2=findViewById(R.id.textView2);
        ArrayList<Show>l=db.getRow();
        tv.setText(l.get(0).s);
        tv1.setText(l.get(0).g);
        tv2.setText(l.get(0).q);


    }

}
